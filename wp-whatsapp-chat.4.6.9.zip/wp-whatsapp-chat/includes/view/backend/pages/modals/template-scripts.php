<script type="text/html" id='tmpl-qlwapp-modal-window'>
<?php include_once(QLWAPP_PLUGIN_DIR . 'includes/view/backend/pages/modals/contact/modal-contact.php'); ?> 
</script>

<script type="text/html" id='tmpl-subview-header'> 
<?php include_once(QLWAPP_PLUGIN_DIR . 'includes/view/backend/pages/modals/contact/panel-header.php'); ?>   
</script>

<script type="text/html" id='tmpl-subview-tabs'>
<?php include_once(QLWAPP_PLUGIN_DIR . 'includes/view/backend/pages/modals/contact/panel-tabs.php'); ?> 
</script>

<script type="text/html" id='tmpl-subview-contact'>
<?php include_once(QLWAPP_PLUGIN_DIR . 'includes/view/backend/pages/modals/contact/panel-contact.php'); ?> 
</script>

<script type="text/html" id='tmpl-subview-contact-chat'>
<?php include_once(QLWAPP_PLUGIN_DIR . 'includes/view/backend/pages/modals/contact/panel-contact-chat.php'); ?> 
</script>

<script type="text/html" id='tmpl-subview-contact-info'> 
<?php include_once(QLWAPP_PLUGIN_DIR . 'includes/view/backend/pages/modals/contact/panel-info.php'); ?>  
</script> 

<script type="text/html" id='tmpl-subview-visibility'>
<?php include_once(QLWAPP_PLUGIN_DIR . 'includes/view/backend/pages/modals/contact/panel-visibility.php'); ?> 
</script>

<script type="text/html" id='tmpl-subview-footer'>
  <?php include_once(QLWAPP_PLUGIN_DIR . 'includes/view/backend/pages/modals/contact/panel-footer.php'); ?>   
</script>   
